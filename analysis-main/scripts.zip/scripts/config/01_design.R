# ============================================================
# 01_design_cfg.R
# Experimental design + inferential thresholds
# ============================================================

design_cfg <- function() {
  
  list(
    
    # --------------------------------------------------------
    # Core sequence design
    # --------------------------------------------------------
    
    seq = list(
      endowment = 100L,
      xmin      = 0.01,
      seq_n     = 64L,
      coin_prob = 0.5,
      
      treatments = list(
        m25 = 2.5,
        m19 = 1.9
      ),
      
      # --------------------------------------------------------
      # Label translation: Czech oTree labels -> English
      # --------------------------------------------------------
      label_recode = list(
        H = "H", # heads are coded as H in oTree
        O = "T",  # tails are coded as O in oTree 
        NB = "NB" # no bet is coded as NB in oTree
      ),
      
      # --------------------------------------------------------
      # Side Labels and Anchors used in pipeline
      # --------------------------------------------------------
      side_labels = list(
        heads = "H",
        tails = "T",
        nobet = "NB"
      ),
    
      anchor_labels = list(
        pure_heads = "HHHHHH",
        pure_tails = "TTTTTT"
      )
    
    ),
   
    # --------------------------------------------------------
    # MPL risk elicitation
    # --------------------------------------------------------
    mpl = list(
      K      = 19L, # number of rows/lotteries
      p      = (1:19) / 20, # row k: probability of the high payoff, 0.05, ..., 0.95
      A_high = 20.0,
      A_low  = 16.0,
      B_high = 38.5,
      B_low  = 1.0,
      label_safe  = "A",
      label_risky = "B"
    ),
    
    # --------------------------------------------------------
    # LOT-R (scoring)
    # --------------------------------------------------------
    lotr = list(
      scale_min = 0L,
      scale_max = 4L,
      item_cols = paste0("q", 1:10),
      scored_items = c("q1", "q3", "q4", "q7", "q9", "q10"),
      rev_items    = c("q3", "q7", "q9")
    ),
    
    # --------------------------------------------------------
    # RQ1 (Betting)
    # --------------------------------------------------------
    rq1 = list(
      rho = c(0.10, 0.08, 0.12),
      ppc_cut = 0.95   # check passes if P(rep >= obs) >= 1 - ppc_cut (implementation choice; the preregistration gives no numeric cut)
    ),
    
    # --------------------------------------------------------
    # RQ2 (Staking)
    # --------------------------------------------------------
    rq2 = list(
      rho                = c(0.05, 0.03, 0.08),
      sd_floor           = 2,
      sd_floor_sens_low  = 1,
      sd_floor_sens_high = 5,
      min_bets           = 3L,
      ppc_cut            = 0.95   # all-in check: Gaussian accepted if P(rep >= obs) >= 1 - ppc_cut
    ),
    
    # --------------------------------------------------------
    # RQ3
    # --------------------------------------------------------
    rq3 = list(
      rho = c(0.05, 0.03, 0.08),
      ppc_cut = 0.95   # supplementary check passes if the two-sided posterior predictive p >= 1 - ppc_cut
    ),
    
    # --------------------------------------------------------
    # RQ4 (Side choice on betting trials)
    # --------------------------------------------------------
    rq4 = list(
      rho = c(0.05, 0.03, 0.08),     # first = main (tolerance band around hbar)
      ppc_overdisp_cut = 0.95        # trigger cutoff for the Beta–Binomial robustness fit (implementation choice; the preregistration gives no numeric cut)
    ),
    
    # --------------------------------------------------------
    # EX1 (Distributional similarity and GHI)
    # --------------------------------------------------------
    ex1 = list(
      eps   = c(0.05, 0.03, 0.08),  # tolerance band; first = main analysis
      eta   = 1e-6,                  # weight stabiliser
      delta = c(0.05, 0.03, 0.08)   # chi_s / chi_i classification threshold; first = main
    ),
    
    # --------------------------------------------------------
    # EX2
    # --------------------------------------------------------
    ex2 = list(
      min_Nk      = 10L
    ),
    
    # --------------------------------------------------------
    # Normative a* classification
    # --------------------------------------------------------
    a_flags = list(
      betting_normative = list(
        m25 = TRUE,
        m19 = FALSE
      ),
      tau = c(0.90, 0.80, 0.95) # first value is for the primary analysis
    ),
    
    # --------------------------------------------------------
    # Additional exclusion thresholds
    # --------------------------------------------------------
    # exclusion = list(
    #   P0 = c(0.80, 0.90, 0.95)
    # ),
    
    # --------------------------------------------------------
    # Drift parametrization (preregistered)
    # --------------------------------------------------------
  
    drift = list(
      
      # Shared parametrization for all drift terms (preregistered)
      params = list(
        linear = list(
          block_centers    = c(-1.5, -0.5, 0.5, 1.5),
          prior_gamma_mean = 0,
          prior_gamma_sd   = 0.3
        ),
        categorical = list(
          prior_gamma_sd = 0.3
        )
      ),
      
      # Outcome mapped to each RQ
      rq1 = list(outcome = "bet"),
      rq2 = list(outcome = "stake"),
      rq3 = list(outcome = "stake"),
      rq4 = list(outcome = "side")
    )
    
    
  )
}